(() => {
  "use strict";
  const canvas = document.getElementById("arena");
  const ctx = canvas.getContext("2d");
  const $ = id => document.getElementById(id);
  const W = canvas.width, H = canvas.height;
  const keys = new Set();
  const player = {x:300,y:345,hp:100,maxHp:100,energy:100,maxEnergy:100,level:1,xp:0,damage:0,dodges:0,combo:0,bestCombo:0,facing:1,attack:0,attackType:"slash",dash:0,invuln:0};
  const enemy = {x:700,y:270,hp:100,maxHp:100,attack:0,attackType:"slash",cooldown:1.2,flash:0,facing:-1};
  let running=false, finished=false, timeLeft=90, last=0, energyTick=0, enemyThink=0, particles=[], rings=[], floating=[], stars=[], shake=0, soundOn=false, audioCtx=null;
  for(let i=0;i<100;i++) stars.push({x:Math.random()*W,y:Math.random()*H*.55,r:Math.random()*1.6+.2,a:Math.random()*.7+.2});
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const rand=(a,b)=>Math.random()*(b-a)+a;
  function log(msg,color="blue"){const box=$("combatLog");box.innerHTML=`<div><span class="log-dot ${color}"></span> ${msg}</div>`+box.innerHTML;while(box.children.length>3)box.lastChild.remove()}
  function beep(freq=440,duration=.08,type="sine"){if(!soundOn)return;try{audioCtx ||= new (window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.value=freq;g.gain.value=.045;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.stop(audioCtx.currentTime+duration)}catch(e){}}
  function burst(x,y,color,count=18,power=4){for(let i=0;i<count;i++){const a=rand(0,Math.PI*2),s=rand(.8,power);particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:rand(.25,.7),max:.7,size:rand(1.5,4),color})}}
  function ring(x,y,color,max=90){rings.push({x,y,r:8,max,life:.35,color})}
  function textPop(x,y,text,color="#fff"){floating.push({x,y,text,color,life:.8,vy:-.7})}
  function gainXp(n){player.xp+=n;while(player.xp>=100){player.xp-=100;player.level++;player.maxHp+=10;player.hp=Math.min(player.maxHp,player.hp+25);player.maxEnergy+=5;player.energy=player.maxEnergy;log(`LEVEL UP! You reached level ${player.level}.` ,"blue");burst(player.x,player.y,"#ffdf7a",45,7);beep(740,.22,"triangle")}}
  function updateHud(){
    $("hpText").textContent=`${Math.ceil(player.hp)} / ${player.maxHp}`;$("hpBar").style.width=`${100*player.hp/player.maxHp}%`;
    $("energyText").textContent=`${Math.floor(player.energy)} / ${player.maxEnergy}`;$("energyBar").style.width=`${100*player.energy/player.maxEnergy}%`;
    $("enemyHpText").textContent=`${Math.ceil(enemy.hp)} / ${enemy.maxHp}`;$("enemyHpBar").style.width=`${100*enemy.hp/enemy.maxHp}%`;
    $("level").textContent=player.level;$("damageStat").textContent=player.damage;$("dodgeStat").textContent=player.dodges;$("bestComboStat").textContent=player.bestCombo+"×";
    $("xpText").textContent=`${player.xp} / 100 XP`;$("xpBar").style.width=player.xp+"%";
    $("combo").innerHTML=`COMBO <strong>×${player.combo}</strong>`;
    $("enemyStatus").textContent=enemy.hp<=0?"DEFEATED":enemy.flash>0?"UNDER ATTACK":"LOCKED ON";
    $("roundTimer").textContent=`${String(Math.floor(timeLeft/60)).padStart(2,"0")}:${String(Math.floor(timeLeft%60)).padStart(2,"0")}`;
  }
  function doAbility(type){
    if(!running||finished)return;
    const specs={slash:{cost:0,cd:0.25,damage:9,range:155,color:"#45eaff",label:"SHADOW SLASH"},burst:{cost:25,cd:.7,damage:21,range:235,color:"#53a7ff",label:"AURA BURST"},nova:{cost:45,cd:1.5,damage:34,range:290,color:"#c36bff",label:"VOID NOVA"},dash:{cost:15,cd:.55,damage:0,range:0,color:"#9daeff",label:"PHANTOM DASH"}};
    const s=specs[type];if(player.energy<s.cost){log("Not enough aura energy!","red");beep(150,.08);return}
    const now=performance.now();if((player.lastAbility?.[type]||0)>now){return}player.lastAbility ||= {};player.lastAbility[type]=now+s.cd*1000;
    player.energy-=s.cost;player.attack=.24;player.attackType=type;
    if(type==="dash"){player.dash=.24;player.invuln=.32;player.x=clamp(player.x+player.facing*105,80,W-80);player.dodges++;burst(player.x-player.facing*25,player.y,"#77caff",22,5);ring(player.x,player.y,"#9daeff",65);textPop(player.x,player.y-45,"DODGE!","#a6cfff");beep(560,.1,"triangle");updateHud();return}
    const distance=Math.abs(enemy.x-player.x);
    burst(player.x+player.facing*38,player.y-15,s.color,type==="nova"?34:17,type==="nova"?8:5);
    ring(player.x+player.facing*45,player.y-12,s.color,type==="nova"?150:85);
    if(distance<s.range && enemy.hp>0){
      const damage=Math.round(s.damage+player.level*1.5);enemy.hp=Math.max(0,enemy.hp-damage);enemy.flash=.2;enemy.x=clamp(enemy.x+player.facing*(type==="nova"?45:25),65,W-65);
      player.damage+=damage;player.combo++;player.bestCombo=Math.max(player.bestCombo,player.combo);gainXp(damage);textPop(enemy.x,enemy.y-55,`-${damage}`,s.color);burst(enemy.x,enemy.y-12,s.color,12,4);shake=type==="nova"?9:4;
      log(`${s.label} landed for ${damage} damage!`,"blue");beep(type==="nova"?180:420,.13,type==="nova"?"sawtooth":"triangle");
      if(enemy.hp<=0){finished=true;running=false;timeLeft=Math.max(0,timeLeft);$("roundState").textContent="VICTORY";showMessage("RIVAL DEFEATED","YOU OWN THIS REALM",`Damage dealt: ${player.damage} · Level ${player.level}`,"PLAY AGAIN");gainXp(40);burst(enemy.x,enemy.y,"#ff4f88",70,9);log("Victory! You earned 40 bonus XP.","blue")}
    }else{player.combo=0;log(`${s.label} missed — get closer!`,"red");beep(220,.06)}
    updateHud();
  }
  function enemyAttack(){
    if(enemy.hp<=0||!running)return;
    enemy.attack=.3;enemy.attackType=Math.random()<.6?"slash":"burst";
    const dist=Math.abs(player.x-enemy.x);
    if(dist<190&&player.invuln<=0){const d=enemy.attackType==="burst"?13:8;player.hp=Math.max(0,player.hp-d);player.combo=0;shake=5;textPop(player.x,player.y-45,`-${d}`,"#ff5d82");burst(player.x,player.y-10,"#ff4d75",12,4);log(`Crimson Rival hit you for ${d} damage.`,"red");beep(120,.12,"sawtooth");if(player.hp<=0){finished=true;running=false;$("roundState").textContent="DEFEAT";showMessage("REALM LOST","RISE AGAIN, FIGHTER",`You dealt ${player.damage} damage. Every rematch makes you stronger.`,"TRY AGAIN")}}
    else if(player.invuln>0){player.dodges++;textPop(player.x,player.y-42,"EVADE!","#70f4ff");burst(player.x,player.y,"#70f4ff",8,3)}
    updateHud();
  }
  function showMessage(kicker,title,desc,button){$("centerMessage").innerHTML=`<div class="message-kicker">${kicker}</div><h2>${title}</h2><p>${desc}</p><button id="startBtn" class="primary-btn">${button} <span>➜</span></button>`;$("centerMessage").classList.remove("hidden");$("startBtn").addEventListener("click",startGame)}
  function startGame(){player.x=300;player.y=345;player.hp=player.maxHp;player.energy=player.maxEnergy;player.combo=0;player.damage=0;player.dodges=0;player.bestCombo=0;player.xp=0;player.level=1;player.maxHp=100;player.maxEnergy=100;player.lastAbility={};enemy.x=700;enemy.hp=100;enemy.flash=0;enemy.cooldown=1.2;timeLeft=90;particles=[];rings=[];floating=[];finished=false;running=true;$("roundState").textContent="FIGHT!";$("centerMessage").classList.add("hidden");log("The match begins. Make your move!","blue");updateHud()}
  function update(dt){
    if(running&&!finished){timeLeft-=dt;if(timeLeft<=0){timeLeft=0;running=false;finished=true;if(player.hp>=enemy.hp){showMessage("TIME IS UP","NARROW VICTORY",`Your HP: ${Math.ceil(player.hp)} · Rival HP: ${Math.ceil(enemy.hp)}`,"PLAY AGAIN")}else{showMessage("TIME IS UP","THE RIVAL PREVAILS",`Your HP: ${Math.ceil(player.hp)} · Rival HP: ${Math.ceil(enemy.hp)}`,"TRY AGAIN")}$("roundState").textContent="TIME UP"}
      let dir=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0);if(dir){player.x=clamp(player.x+dir*230*dt,55,W-55);player.facing=dir>0?1:-1}
      energyTick+=dt;if(energyTick>.18){player.energy=Math.min(player.maxEnergy,player.energy+2);energyTick=0}
      enemyThink+=dt;enemy.cooldown-=dt;enemy.facing=player.x<enemy.x?-1:1;
      if(enemyThink>.45){enemyThink=0;if(Math.abs(enemy.x-player.x)>130){enemy.x+=Math.sign(player.x-enemy.x)*Math.min(75*dt,Math.abs(enemy.x-player.x)-110)}}
      if(enemy.cooldown<=0){enemyAttack();enemy.cooldown=rand(1.15,2.1)}
      player.attack=Math.max(0,player.attack-dt);player.dash=Math.max(0,player.dash-dt);player.invuln=Math.max(0,player.invuln-dt);enemy.attack=Math.max(0,enemy.attack-dt);enemy.flash=Math.max(0,enemy.flash-dt);
      if(Math.random()<dt*2.2){const e=enemy.hp>0?enemy:player;particles.push({x:e.x+rand(-20,20),y:e.y+rand(-35,5),vx:rand(-12,12),vy:rand(-22,-4),life:.45,max:.45,size:rand(1,3),color:e===player?"#36dcff":"#ff4d7e"})}
    }
    particles.forEach(p=>{p.x+=p.vx;p.y+=p.vy;p.vx*=.99;p.vy+=.02;p.life-=dt});particles=particles.filter(p=>p.life>0);
    rings.forEach(r=>{r.r+=(r.max-r.r)*dt*8;r.life-=dt});rings=rings.filter(r=>r.life>0);
    floating.forEach(f=>{f.y+=f.vy;f.life-=dt});floating=floating.filter(f=>f.life>0);
    updateHud();
  }
  function drawBackground(){
    const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,"#080d28");sky.addColorStop(.5,"#172a59");sky.addColorStop(1,"#080d20");ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
    ctx.save();for(const s of stars){ctx.globalAlpha=s.a;ctx.fillStyle="#b9e8ff";ctx.beginPath();ctx.arc(s.x,s.y,s.r,0,Math.PI*2);ctx.fill()}ctx.restore();
    const moon=ctx.createRadialGradient(775,90,4,775,90,80);moon.addColorStop(0,"#f4fbff");moon.addColorStop(.25,"#a8d6ff");moon.addColorStop(1,"#629bff00");ctx.fillStyle=moon;ctx.beginPath();ctx.arc(775,90,80,0,Math.PI*2);ctx.fill();
    ctx.fillStyle="#0b1632";for(let i=0;i<9;i++){let x=i*135-20;ctx.beginPath();ctx.moveTo(x,220);ctx.lineTo(x,120+((i*23)%40));ctx.lineTo(x+55,95+((i*19)%40));ctx.lineTo(x+105,130+((i*23)%40));ctx.lineTo(x+105,220);ctx.closePath();ctx.fill();ctx.fillRect(x+15,145,8,75);ctx.fillRect(x+75,145,8,75)}
    // temple silhouette
    ctx.fillStyle="#0b1229";ctx.fillRect(205,140,590,145);ctx.fillRect(260,115,480,35);ctx.beginPath();ctx.moveTo(170,142);ctx.lineTo(500,65);ctx.lineTo(830,142);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(235,115);ctx.lineTo(500,45);ctx.lineTo(765,115);ctx.closePath();ctx.fill();
    ctx.strokeStyle="#1d4d85";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(170,142);ctx.lineTo(500,65);ctx.lineTo(830,142);ctx.stroke();ctx.beginPath();ctx.moveTo(235,115);ctx.lineTo(500,45);ctx.lineTo(765,115);ctx.stroke();
    for(let x=275;x<740;x+=58){ctx.fillStyle="#15294a";ctx.fillRect(x,158,22,95);ctx.fillStyle="#f8b75b";ctx.globalAlpha=.55;ctx.fillRect(x+8,180,5,20);ctx.globalAlpha=1}
    // arena perspective floor
    ctx.fillStyle="#101a37";ctx.beginPath();ctx.moveTo(0,255);ctx.lineTo(W,255);ctx.lineTo(W,H);ctx.lineTo(0,H);ctx.closePath();ctx.fill();
    const floor=ctx.createLinearGradient(0,255,0,H);floor.addColorStop(0,"#243961");floor.addColorStop(1,"#090e20");ctx.fillStyle=floor;ctx.fillRect(0,255,W,H-255);
    ctx.strokeStyle="#3c75ad";ctx.globalAlpha=.35;ctx.lineWidth=1;
    for(let y=265;y<H;y+=Math.max(8,(y-250)*.11)){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
    for(let x=-500;x<1500;x+=100){ctx.beginPath();ctx.moveTo(500,250);ctx.lineTo(x,H);ctx.stroke()}ctx.globalAlpha=1;
    ctx.strokeStyle="#42dfff";ctx.globalAlpha=.22;ctx.lineWidth=3;ctx.strokeRect(40,267,920,280);ctx.globalAlpha=1;
    // floating torii-like pillars
    for(let x of [45,950]){ctx.fillStyle="#09132c";ctx.fillRect(x-8,125,16,160);ctx.fillRect(x-25,120,50,10);ctx.fillRect(x-35,108,70,9)}
  }
  function drawFighter(f,isPlayer){
    const color=isPlayer?"#35e7ff":"#ff3f77", dark=isPlayer?"#0b3973":"#6d1538", light=isPlayer?"#c8fbff":"#ffd4e0";
    const aura=ctx.createRadialGradient(f.x,f.y-18,3,f.x,f.y-18,isPlayer?68:62);aura.addColorStop(0,color+"55");aura.addColorStop(1,color+"00");ctx.fillStyle=aura;ctx.beginPath();ctx.ellipse(f.x,f.y-18,70,80,0,0,Math.PI*2);ctx.fill();
    // aura sparks
    for(let i=0;i<7;i++){let a=performance.now()*.001*(isPlayer?2:-2)+i*6.28/7;let rx=f.x+Math.cos(a)*randStatic(28,42),ry=f.y-18+Math.sin(a)*randStatic(28,42);ctx.strokeStyle=color;ctx.globalAlpha=.25+.35*Math.sin(a*2)**2;ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(rx,ry);ctx.lineTo(rx+Math.cos(a)*randStatic(5,13),ry-10);ctx.stroke()}ctx.globalAlpha=1;
    // shadow
    ctx.fillStyle="#02050c88";ctx.beginPath();ctx.ellipse(f.x,f.y+3,31,8,0,0,Math.PI*2);ctx.fill();
    ctx.save();ctx.translate(f.x,f.y);if(f.facing<0)ctx.scale(-1,1);
    // legs
    ctx.strokeStyle=dark;ctx.lineWidth=13;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-8,-13);ctx.lineTo(-14,3);ctx.moveTo(8,-13);ctx.lineTo(15,2);ctx.stroke();
    ctx.strokeStyle=light;ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-17,3);ctx.lineTo(-7,3);ctx.moveTo(10,3);ctx.lineTo(20,3);ctx.stroke();
    // body / coat
    ctx.fillStyle=dark;ctx.beginPath();ctx.moveTo(-17,-40);ctx.lineTo(14,-40);ctx.lineTo(23,-13);ctx.lineTo(0,-7);ctx.lineTo(-23,-14);ctx.closePath();ctx.fill();
    ctx.fillStyle=light;ctx.beginPath();ctx.moveTo(-5,-38);ctx.lineTo(3,-38);ctx.lineTo(9,-14);ctx.lineTo(0,-10);ctx.closePath();ctx.fill();
    // arm and weapon pose
    ctx.strokeStyle=dark;ctx.lineWidth=10;ctx.beginPath();ctx.moveTo(-13,-34);ctx.lineTo(-24,-21);ctx.stroke();ctx.strokeStyle=light;ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(-25,-21);ctx.lineTo(-31,-17);ctx.stroke();
    const swing=f.attack>0?Math.sin((.24-f.attack)*Math.PI/.24)*24:0;
    ctx.strokeStyle=dark;ctx.lineWidth=11;ctx.beginPath();ctx.moveTo(12,-34);ctx.lineTo(25+swing,-28);ctx.stroke();
    ctx.strokeStyle=color;ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(24+swing,-28);ctx.lineTo(43+swing,-15);ctx.stroke();
    ctx.strokeStyle=light;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(25+swing,-28);ctx.lineTo(45+swing,-10);ctx.stroke();
    // head
    ctx.fillStyle=light;ctx.beginPath();ctx.ellipse(0,-50,13,15,0,0,Math.PI*2);ctx.fill();
    // anime hair spikes
    ctx.fillStyle=isPlayer?"#061224":"#351020";ctx.beginPath();ctx.moveTo(-14,-53);ctx.lineTo(-19,-68);ctx.lineTo(-8,-61);ctx.lineTo(-5,-76);ctx.lineTo(2,-63);ctx.lineTo(12,-72);ctx.lineTo(12,-59);ctx.lineTo(17,-53);ctx.lineTo(7,-46);ctx.lineTo(-10,-47);ctx.closePath();ctx.fill();
    ctx.fillStyle=color;ctx.fillRect(3,-52,7,2);
    if(f.attack>0){ctx.strokeStyle=color;ctx.globalAlpha=.85;ctx.lineWidth=f.attackType==="nova"?8:4;ctx.beginPath();ctx.arc(18,-29,43,-1.1,.8);ctx.stroke();ctx.globalAlpha=1}
    if(f.invuln>0){ctx.strokeStyle="#a3f5ff";ctx.lineWidth=2;ctx.globalAlpha=.8;ctx.beginPath();ctx.ellipse(0,-25,35,42,0,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1}
    ctx.restore();
    // nameplate
    ctx.textAlign="center";ctx.font="700 12px Orbitron";ctx.fillStyle="#fff";ctx.fillText(isPlayer?"SHADOW STRIKER":"CRIMSON RIVAL",f.x,f.y-98);ctx.fillStyle="#162342";ctx.fillRect(f.x-38,f.y-88,76,5);ctx.fillStyle=color;ctx.fillRect(f.x-38,f.y-88,76*(f.hp/f.maxHp),5);
  }
  function randStatic(a,b){return a+(b-a)*.5}
  function drawEffects(){
    for(const r of rings){ctx.globalAlpha=Math.max(0,r.life/.35);ctx.strokeStyle=r.color;ctx.lineWidth=3;ctx.beginPath();ctx.arc(r.x,r.y,r.r,0,Math.PI*2);ctx.stroke()}ctx.globalAlpha=1;
    for(const p of particles){ctx.globalAlpha=Math.max(0,p.life/p.max);ctx.fillStyle=p.color;ctx.shadowColor=p.color;ctx.shadowBlur=10;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill()}ctx.shadowBlur=0;ctx.globalAlpha=1;
    for(const f of floating){ctx.globalAlpha=Math.min(1,f.life*2);ctx.textAlign="center";ctx.font="800 16px Orbitron";ctx.fillStyle=f.color;ctx.shadowColor=f.color;ctx.shadowBlur=10;ctx.fillText(f.text,f.x,f.y)}ctx.shadowBlur=0;ctx.globalAlpha=1;
  }
  function draw(){
    ctx.save();if(shake>0){ctx.translate(rand(-shake,shake),rand(-shake,shake));shake=Math.max(0,shake-.5)}
    drawBackground();
    // ground glows
    ctx.globalAlpha=.3;ctx.fillStyle="#238aff";ctx.beginPath();ctx.ellipse(player.x,H-35,75,15,0,0,Math.PI*2);ctx.fill();ctx.fillStyle="#ff2e70";ctx.beginPath();ctx.ellipse(enemy.x,H-35,75,15,0,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
    drawFighter(player,true);if(enemy.hp>0)drawFighter(enemy,false);drawEffects();ctx.restore();
  }
  function loop(ts){const dt=Math.min(.033,(ts-last)/1000||0);last=ts;update(dt);draw();requestAnimationFrame(loop)}
  document.addEventListener("keydown",e=>{const k=e.key.toLowerCase();if([" ","arrowleft","arrowright"].includes(k))e.preventDefault();keys.add(k);if(e.repeat)return;if(k==="j")doAbility("slash");if(k==="k")doAbility("burst");if(k==="l")doAbility("nova");if(k===" ")doAbility("dash");if((k==="enter")&&!running)startGame()});
  document.addEventListener("keyup",e=>keys.delete(e.key.toLowerCase()));
  document.querySelectorAll(".ability").forEach(b=>b.addEventListener("click",()=>doAbility(b.dataset.ability)));
  $("startBtn").addEventListener("click",startGame);$("restartBtn").addEventListener("click",startGame);
  $("soundBtn").addEventListener("click",()=>{soundOn=!soundOn;$("soundBtn").textContent=`♫ Sound: ${soundOn?"On":"Off"}`;if(soundOn)beep(540,.1)});
  $("mobileLeft").addEventListener("pointerdown",()=>keys.add("a"));$("mobileLeft").addEventListener("pointerup",()=>keys.delete("a"));$("mobileLeft").addEventListener("pointerleave",()=>keys.delete("a"));
  $("mobileRight").addEventListener("pointerdown",()=>keys.add("d"));$("mobileRight").addEventListener("pointerup",()=>keys.delete("d"));$("mobileRight").addEventListener("pointerleave",()=>keys.delete("d"));
  $("mobileAttack").addEventListener("click",()=>doAbility("slash"));
  updateHud();requestAnimationFrame(loop);
})();
# Shattered Realms — Anime Arena

A small, playable anime-inspired browser fighting game made with plain HTML, CSS, and JavaScript. No installs or build tools are required.

## Play locally
1. Download and unzip `shattered-realms.zip`.
2. Open the `shattered_realms` folder.
3. Double-click `index.html` to open it in a modern browser.
4. Press **ENTER THE ARENA** and fight!

## Controls
- **A / D** or **← / →**: move
- **J**: Shadow Slash
- **K**: Aura Burst (uses 25 aura)
- **L**: Void Nova (uses 45 aura)
- **Space**: Phantom Dash (uses 15 aura)
- Buttons also work with touch; mobile movement buttons appear on smaller screens.

## Publish free with GitHub Pages
1. Sign in to GitHub and create a **new public repository** named `shattered-realms`.
2. Upload `index.html`, `style.css`, `game.js`, and `README.md` from this folder into the repository's **root** (not inside another nested folder).
3. Open the repository's **Settings** → **Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait a minute or two. The published address will look like `https://YOUR-USERNAME.github.io/shattered-realms/`.
7. If you update the game later, upload the changed files and commit the changes.

## Customize
- Change colours and layout in `style.css`.
- Change damage, energy costs, enemy attack timing, and XP in `game.js`.
- Change the title and interface text in `index.html`.

## Notes
- This is a single-player game with a computer-controlled rival, not online multiplayer.
- The Google Fonts import is optional; if offline, the browser falls back to standard fonts.
